<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Memcached settings
| -------------------------------------------------------------------------
| Your Memcached servers can be specified below.
|
<<<<<<< HEAD
|	See: https://codeigniter.com/user_guide/libraries/caching.html#memcached
=======
|	See: https://codeigniter.com/userguide3/libraries/caching.html#memcached
>>>>>>> 4ac3e12faf0b0ddcad1091c595a68c1d1302375d
|
*/
$config = array(
	'default' => array(
		'hostname' => '127.0.0.1',
		'port'     => '11211',
		'weight'   => '1',
	),
);
