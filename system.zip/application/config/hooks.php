<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Hooks
| -------------------------------------------------------------------------
| This file lets you define "hooks" to extend CI without hacking the core
| files.  Please see the user guide for info:
|
<<<<<<< HEAD
|	https://codeigniter.com/user_guide/general/hooks.html
=======
|	https://codeigniter.com/userguide3/general/hooks.html
>>>>>>> 4ac3e12faf0b0ddcad1091c595a68c1d1302375d
|
*/
