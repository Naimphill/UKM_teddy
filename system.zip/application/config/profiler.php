<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Profiler Sections
| -------------------------------------------------------------------------
| This file lets you determine whether or not various sections of Profiler
| data are displayed when the Profiler is enabled.
| Please see the user guide for info:
|
<<<<<<< HEAD
|	https://codeigniter.com/user_guide/general/profiling.html
=======
|	https://codeigniter.com/userguide3/general/profiling.html
>>>>>>> 4ac3e12faf0b0ddcad1091c595a68c1d1302375d
|
*/
